var mysql = require('mysql');
var conn = mysql.createConnection({
	host : '192.168.0.30',
	user : 'root',
	password : 'asd123',
	database : 'unidata'
});
conn.connect();

var sql = 'SELECT * FROM 강사';
conn.query(sql,function(err,rows,fields){
	if(err){
		console.log(err);
	} else {
		for(var i=0;i<rows.length;i++){
			console.log(rows[i].강사ID);
		}
	}
});
var sql='INSERT INTO 강사(강사ID,PASSWORD,이름,핸드폰번호,경력) VALUES(?,?,?,?,?)';
var params = ['11','2398','주호민','010-6888-7797','9'];
conn.query(sql,params,function(err,rows,fields){
	if(err){
		console.log(err);
	}else{
		console.log(rows.insertId);
	}

});

conn.end();
