
/*var router=express.Router();*/
var mysql=require('mysql');
var conn = mysql.createConnection({
	host : '192.168.0.30',
	user : 'root',
	password : 'asd123',
	database : 'unidata'
});
conn.connect();

var express=require('express');
var session = require('express-session');	/*세션을 사용하기 위해*/
var app=express();
var passport=require('passport');
var LocalStrategy = require('passport-local').Strategy;
var bkfd2Password = require('pbkdf2-password');
var hasher = bkfd2Password();
var MYSQLStore = require('express-mysql-session')(session);	
/*new :  body parser install */
var bodyParser=require('body-parser');
/*new : app.use body-parser*/
app.use(bodyParser.urlencoded({ extended: false }));


app.set('views','./master');
app.set('view engine','ejs');

passport.use(new LocalStrategy(
	function(username,password,done){
		var id = username;
		var pw = password;
		var sql = 'SELECT * FROM 관리자 WHERE 관리자ID=?';
		conn.query(sql,['local:'+id], function(err,results){
			console.log(result);
			if(err){
				return done('There is no user');
			}
			var id = results[0];
			return hasher({password:pw, salt:user.salt}, function(err,pass,salt,hash){
				if(hash===user.password){
					console.log('LocalStrategy',user);
					done(null,user);
				} else {
					done(null,false);
				}
			});

		});
	}));	

passport.serializeUser(function(user,done){
	console.log('serializeUser', user);
	done(null, user.관리자ID);	/*??*/
});

passport.deserializeUser(function(id,done){
	console.log('deserializeUser', id);
	var sql = 'SELECT * FROM 관리자 WHERE 관리자ID=?';
	conn.query(sql,[id],function(err,results){
		if(err){
			console.log(err);
			done('there is no user');
		} else {
			done(null,results[0]);
		}
	});
/*	for(var i=0;i<관리자.length;i++){		// users==관리자??
		var user = 관리자[i];
		if(user.관리자ID===id){
			return done(null,user);
		}
	}
	done('There is no user');*/
});


/*session 세팅-new - mysql session 접속정보를 따로 설정해야 한다*/
app.use(session({
	secret: '234$dlkjlwi873orneu#g',	//그냥 랜덤한값
	resave: false,
	saveUninitialized: true,
	store:new MYSQLStore({
		host: '192.168.0.30',
		port: 3306,
		user: 'root',
		password: 'asd123',
		database: 'unidata'
	})
}));

/*session-login1 -new*/
app.post('/auth/login',function(req,res){
	var user={
		username:'sofia',
		password:'111',		/*<-나중에 이건 DB에서 가져오는 형식으로*/
		masterName:'sofia kim'
	};
	var uname = req.body.username;
	var pwd = req.body.password;
	if(uname===user.username && pwd===user.password){
		req.session.masterName = user.masterName;	
		res.redirect('/home');
	} else {
		res.send('Who are you?');	/*ㅇ기에 res.send(Login Again)?*/
	}
	res.send(uname);	/*<-이걸 처리하려면 bodyParser 모듈이 있어야 함*/
});
app.get('/auth/login',function(req,res){
	var output=`
	<head>
	<h1>Login</h1>
	<form action="/auth/login" method="post">
		<p>
			<input type="text" name="username" placeholder="username">
		</p>
		<p>
			<input type="password" name="password" placeholder="password">	
		</p>
		<p>
			<input type="submit">
		</p>
	</form>
	</head>		

	`;
	res.send(output);
});

app.get('/auth/logout',function(req,res){
	/*session정보 지워야 - delete*/
	delete req.session.masterName;
	res.redirect('login');
});

/*login성공시 오는 홈페이지(home)*/
app.get('/home',function(req,res){
	if(req.session.masterName){
		res.send(`
			<h1>Hello, ${req.session.masterName}</h1>	
			`);
	} else {
		res.render('login');
	}
	res.render('home',{masterName:masterName});
});



/*5. mysql의 목록 출력*/
app.get('/list/center',function(req,res){
	var sql='SELECT * FROM 기관';
	conn.query(sql,function(err,rows,fields){
		if(err) console.log("err :"+err);
		console.log("rows :"+rows);
		res.render('CenterList',{rows:rows});	
	});
});


/*1. 로그인 기능*/
app.get('/login', function(req, res){
  /*if(req.session.username) {
    res.send(`
      <h1>Hello</h1>
      <a href="/auth/logout">logout</a>
    `);
    복잡하니깐 res.render(hello)등으로 처리하기
  } else {
    res.send(`
      <h1>Master Login</h1>
      <a href="/auth/login">Login</a>
    `);
  }*/
  res.render('login');
});

app.post('/auth/login',passport.authenticate('local',{
	successRedirect: '/home',
	failureRedirect: '/Again',
	failureFlash: false
	})
);


app.listen(3000,function(){
	console.log('Connected!');
});