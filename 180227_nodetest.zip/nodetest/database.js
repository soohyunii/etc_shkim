var mysql = require('mysql');
var connection = mysql.createConnection({
	host : '192.168.0.30',
	user : 'root',
	password : 'asd123',
	database : 'unidata'
});
connection.connect();
/*
connection.query('SELECT now()', 
    function(err, rows, fields) {
      if (err) throw err;
 
      console.log( rows );
    }
);*/
var sql = 'SELECT * FROM 강사';
connection.query(sql,function(err,rows,fields){
	if(err){
		console.log(err);
	} else {
		console.log('rows',rows);
		console.log('fields',fields);
	}
});
connection.end();		//접속이 끊김