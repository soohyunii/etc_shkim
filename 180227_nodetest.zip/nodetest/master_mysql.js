var mysql = require('mysql');
var conn = mysql.createConnection({
	host : '192.168.0.30',
	user : 'root',
	password : 'asd123',
	database : 'unidata'
});
conn.connect();


/*app.locals.pretty=true;	안먹힘 */
var express=require('express');
var app=express();
/*var bodyParser=require('body-paser');
app.use(bodyParser.urlencoded({extended:false}));*/


app.set('views','./master');
app.set('view engine','jade');


app.get('/login',function(req,res){
	res.send(req.query.id+','+req.query.password);
});

/*app.get(['/home','/home/:id'],function(req,res){
	res.render('notLogin')
});*/

app.get(['/home','/home/:id'],function(req,res){
	var list = `
	<a href="/home?id=0">Center</a><br>
	<a href="/home?id=1">Department</a><br>
	<a href="/home?id=2">Class</a><br>
	`
	res.send(list);
});

app.post(['/home','/home/:id'],function(req,res){
	res.render('home');
});

app.get('/register',function(req,res){
	res.render('notLogin')
});

app.post('/register/center',function(req,res){
	res.render('registerCenter')
});

app.get('/register/center',function(req,res){
	res.render('notLogin')
});

app.post('/register/department',function(req,res){
	res.render('registerDepartment')
});

app.get('/register/department',function(req,res){
	res.render('notLogin')
});

app.post('/register/class',function(req,res){
	res.render('registerClass')
});

app.get('/register/class',function(req,res){
	res.render('notLogin')
});

/*app.get(['/list'],function(req,res){
	res.render('notLogin');
});*/

app.get(['/list'],function(req,res){
	var sql='SELECT * FROM 학과';
	conn.query(sql, function(err,list,fields){
		res.send(list);
	});
});

app.post(['/list'],function(req,res){
	var sql='SELECT * FROM 학과';
	conn.query(sql, function(err,list,fields){
		res.send(list);
	});
});

/*app.get(['/list/center'],function(req,res){
	var sql = 'SELECT * FROM 기관';
	conn.query(sql,function(err,rows,fields){
		res.render('CenterList',{rows:rows});
	});
});*/

app.get(['/list/center'],function(req,res){
	var sql = 'SELECT * FROM 기관';
	conn.query(sql,function(err,rows,fields){

		res.writeHead('200',{'Content-Type':'text/html;charset=utf8'});
		res.write('<h1>List<h1>');
		res.write('<ul><li>'+rows+'</li></ul>');
		res.end();		
	});
});

app.listen(3000,function(){
	console.log('Connected!');
});