var express=require('express');
var router = express.Router();

app.use('/',index);
app.set('views','./master');
app.set('view engine','ejs');

router.get('/',function(req,res,next){
	res.render('index', {title: 'Express'});
});



module.exports = router;