
/*var router=express.Router();*/
var express=require('express');
var session = require('express-session');	/*세션을 사용하기 위해*/
var app=express();
var passport=require('passport');
var LocalStrategy = require('passport-local').Strategy;
var bkfd2Password = require('pbkdf2-password');
var hasher = bkfd2Password();
var mysql=require('mysql');
var conn = mysql.createConnection({
	host : '192.168.0.30',
	user : 'root',
	password : 'asd123',
	database : 'unidata'
});
conn.connect();
var MYSQLStore = require('express-mysql-session')(session);	
/*new :  body parser install */
var bodyParser=require('body-parser');
/*new : app.use body-parser*/
app.use(bodyParser.urlencoded({ extended: false }));
app.use(passport.initialize());


app.set('views','./master');
app.set('view engine','ejs');

var user={
	관리자ID:'local:'+req.body.username,
	PASSWORD: req.body.password,
	
}

passport.use(new LocalStrategy(
	function(username,password,done){
		var id = username;
		var pwd = password;
		var sql = 'SELECT * FROM 관리자 WHERE 관리자ID=?';
		conn.query(sql,['local:'+id], function(err,results){
			if(err){
				return done('There is no user');
			} else {
				if(results.length===0){
					return done(false,null);
				} else {
					if(password,results[0].password){
						return done(false,null);
					} else {
						return done(null,results[0])
					}
				}
			}
		})
	}));


passport.serializeUser(function(user,done){
	console.log('serializeUser', user);
	done(null, user.관리자ID);	/*??*/
});

passport.deserializeUser(function(id,done){
	console.log('deserializeUser', id);
	var sql = 'SELECT * FROM 관리자 WHERE 관리자ID=?';
	conn.query(sql,[id],function(err,results){
		if(err){
			console.log(err);
			done('there is no user');
		} else {
			done(null,results[0]);
		}
	});
});


/*session 세팅-new - mysql session 접속정보를 따로 설정해야 한다*/
app.use(session({
	secret: '234$dlkjlwi873orneu#g',	//그냥 랜덤한값
	resave: false,
	saveUninitialized: true,
	store:new MYSQLStore({
		host: '192.168.0.30',
		port: 3306,
		user: 'root',
		password: 'asd123',
		database: 'unidata'
	})
}));



app.get('/auth/logout',function(req,res){
	/*session정보 지워야 - delete*/
	delete req.session.masterName;
	res.redirect('login');
});

/*login성공시 오는 홈페이지(home)*/
app.get('/home',function(req,res){
	if(req.session.masterName){
		res.send(`
			<h1>Hello, ${req.session.masterName}</h1>	
			`);
	} else {
		res.render('login');
	}
	res.render('home',{masterName:masterName});
});



/*5. mysql의 목록 출력*/
app.get('/list/center',function(req,res){
	var sql='SELECT * FROM 기관';
	conn.query(sql,function(err,rows,fields){
		if(err) console.log("err :"+err);
		console.log("rows :"+rows);
		res.render('CenterList',{rows:rows});	
	});
});


/*1. 로그인 기능*/
/*session-login1 -new*/
app.get('/auth/login',function(req,res){
	res.render('login');
});

app.post('/auth/login',passport.authenticate('local',{
	successRedirect: '/home',
	failureRedirect: '/Again',
	failureFlash: false
	})
);


app.listen(3000,function(){
	console.log('Connected!');
});