
var express=require('express');
var session = require('express-session');	/*세션을 사용하기 위해*/
var app=express();
var LocalStrategy = require('passport-local').Strategy;
var bkfd2Password = require('pbkdf2-password');
var hasher = bkfd2Password();
var mysql=require('mysql');
var bodyParser=require('body-parser');
var conn = mysql.createConnection({
	host : '192.168.0.30',
	user : 'root',
	password : 'asd123',
	database : 'unidata'
});
conn.connect();

app.use(bodyParser.urlencoded({ extended: false }));
app.set('views','./master');
app.set('view engine','ejs');

var pool = mysql.createPool({
	connectionLimit: 3,
	host: '192.168.0.30',
	port: 3000,
	user: 'root',
	password: 'asd123',
	database: 'unidata'
});


/*홈페이지 : 등록 선택 창*/
app.get('/register',function(req,res){
		res.render('register');
});


app.get('/register/center',function(req,res){
	res.render('register_center');
});


/*기관등록 창*/
app.post('/register/center', function(req,res){
	var data={
	"기관ID": req.body.id,
	"PASSWORD": req.body.password, 
	"기관명": req.body.centername, 
	"기관이름": req.body.name, 
	"주소": req.body.address, 
	"기관담당자": req.body.manager, 
	"이메일": req.body.email, 
	"핸드폰번호": req.body.phone
	};

	console.log(data);

	var sql='INSERT INTO 기관 SET ?';
	conn.query(sql,data,function(err,rows,fields){ 
		if(err){
			console.log("err : "+err);
			res.status(500).send('Internal Server Error222');
		} else { 
			console.log("register success!");
			res.render('success');
		}
	});
});

/*success페이지 이후 list또는 register로 rendering*/	


/*기관 : mysql의 목록 출력*/
app.get('/list/center',function(req,res){
	var sql='SELECT * FROM 기관';
	conn.query(sql,function(err,rows,fields){
		if(err) console.log("err :"+err);
		/*console.log("rows :"+rows);*/
		res.render('CenterList',{rows:rows});	
	});
});



app.listen(3000,function(){
	console.log('Connected!');
});