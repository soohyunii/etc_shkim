var mysql = require('mysql');
var conn = mysql.createConnection({
	host : '192.168.0.30',
	user : 'root',
	password : 'asd123',
	database : 'unidata'
});
conn.connect();

var express=require('express');
var app=express();

app.set('view','./view');
app.set('view engine','jade');


app.get(['/home'],function(req,res){
	var sql='SELECT * FROM 기관';
	conn.query(sql, function(err,rows,fields){
		res.send(rows);
		/*res.render(depart);*/
	});
});


/*app.get(['/topic'],functioin(req,res){
	var sql= 'SELECT 학과이름, 분야 FROM 학과';
	conn.query(sql,function(err,rows,fields){
		res.render('view',{topics:topics});
	});
});*/


app.get(['/list'],function(req,res){
	var sql='SELECT * FROM 학과';
	conn.query(sql, function(err,list,fields){
		res.send(list);
		/*res.render('view',{list:list});*/
	});
});

app.listen(3000,function(){
	console.log('Connected!');
});