var express=require('express');
var app=express();
var bodyParser=require('body-parser');
var fs = require('fs');		//파일 시스템을 저장하는 기본 모듈

app.use(bodyParser.urlencoded({extended:false}));
app.locals.pretty=true;
app.set('views','../view_file');
app.set('view engine','jade');

app.get('/register/new',function(req,res){
	res.render('new');
});

/*app.get('/home',function(req,res){
	fs.readFile('view_mysql.html',function(error,data){
		res.writeHead(200,{ 'Content_type':'text/html' });
		res.end(data);
	});
	res.send('hello');
});
*/

app.get('/register',function(req,res){
	fs.readdir('view_file', function(err,files){
		if(err){
			console.log(err);
			res.status(500).send('Internal Server Error');
		}
		res.render('view',{register:files});
	});
});

app.post('/register',function(req,res){
	res.send('HI Post');
});
//?????

 app.listen(3000,function(){
 	console.log('Connected 3000!');
 });

