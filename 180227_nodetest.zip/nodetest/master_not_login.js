
var express=require('express');
var session = require('express-session');	/*세션을 사용하기 위해*/
var app=express();
var LocalStrategy = require('passport-local').Strategy;
var bkfd2Password = require('pbkdf2-password');
var hasher = bkfd2Password();
var mysql=require('mysql');
var bodyParser=require('body-parser');
var conn = mysql.createConnection({
	host : '192.168.0.50',
	user : 'root',
	password : 'gri1234',
	database : 'unidata'
});

/*var index = require('/.master');*/
conn.connect();

app.use(bodyParser.urlencoded({ extended: false }));
/*app.use('/',index);*/
app.set('views','./master');
app.set('view engine','ejs');

var pool = mysql.createPool({
	connectionLimit: 3,
	host: '192.168.0.50',
	port: 3000,
	user: 'root',
	password: 'gri1234',
	database: 'unidata'
});


/*홈페이지 : 등록 선택 창*/
app.get('/register',function(req,res){
		res.render('register');
});


app.get('/register/center',function(req,res){
	res.render('register_center');
});


/*기관등록 창*/
app.post('/register/center', function(req,res){
	var data={
	"기관ID": req.body.id,
	"PASSWORD": req.body.password, 
	"기관명": req.body.centername, 
	"기관이름": req.body.name, 
	"주소": req.body.address, 
	"기관담당자": req.body.manager, 
	"이메일": req.body.email, 
	"핸드폰번호": req.body.phone
	};

	console.log(data);

	var sql='INSERT INTO 기관 SET ?';
	conn.query(sql,data,function(err,rows,fields){ 
		if(err){
			console.log("err : "+err);
			res.status(500).send('Internal Server Error222');
		} else { 
			console.log("register success!");
			res.render('success');
		}
	});
});

/*success페이지 이후 list또는 register로 rendering*/	


/*기관 : mysql의 목록 출력*/
app.get('/list/center',function(req,res){
	var sql='SELECT * FROM 기관';
	conn.query(sql,function(err,rows,fields){
		if(err) console.log("err :"+err);
		/*console.log("rows :"+rows);*/
		res.render('CenterList',{rows:rows});	
	});
});




/*학과 등록 창 - 기관 선택 링크 창 */
app.get(['/register/choice','/register/choice/:id'],function(req,res){
	var sql='SELECT 기관ID, 기관이름 FROM 기관';
	conn.query(sql,function(err,rows,fields){
		var id = req.params.id;
		if(id){
			res.render('register_dept',{id});
			console.log(name);
		} else {
			res.render('CenterChoice',{rows:rows});
		}
	});
});


/*기관(FK) 넘겨주고(req.params.id) DB에 insert*/
app.post('/register/choice/:id',function(req,res){
	var data={
		"학과ID":req.body.did,
		"학과이름":req.body.dname,
		"분야":req.body.dept,
		"학과담당자":req.body.dmanager,
		"이메일":req.body.demail,
		"핸드폰번호":req.body.dphone,
		"기관ID":req.params.id
	};

	console.log(data);

	var sql='INSERT INTO 학과 SET ?';
	conn.query(sql,data,function(err,rows,fields){ 
		if(err){
			console.log("err : "+err);
			res.status(500).send('Internal Server Error333');
		} else { 
			console.log("register success!");
			res.render('success2');
		}
	});
});


/*dept list page*/
app.get('/list/dept',function(req,res){
	var sql='SELECT * FROM 학과';
	conn.query(sql,function(err,rows,fields){
		if(err) console.log("err :"+err);
		res.render('DeptList',{rows:rows});
	});
});




/*class 영역*/
/*app.get(['/register/choice2/:id','/register/choice2/:id/:dept'], function(req,res){
	var sql = 'SELECT * FROM 학과 WHERE 기관ID=?';
	conn.query(sql, function(err,results,fields){
		var id = req.params.id;
		if(id){
			var sql = 'SELECT 학과ID, 학과이름, 기관ID FROM 학과';
			conn.query(sql,[id],function(err,row,fields){
				if(err){
				console.log("err : "+err);
				res.status(500).send('Internal Server Error444');
				} else {
				res.render('DeptChoice',{results:results, row:row[0]});
				}
			});
		} else {
			res.render('DeptChoice',{results:results});
		}
	});
});*/


app.get(['/register/choice2'],function(req,res){
	var sql='SELECT 기관ID, 기관이름 FROM 기관';
	conn.query(sql,function(err,rows,fields){
		var id = req.params.id;
		if(id){
			res.render('DeptChoice',{id});
			console.log(id);
		} else {
			res.render('CenterChoice2',{rows:rows});
		}
	});
});

/*문제되는 부분*/
app.get(['/register/choice2/:id','/register/choice2/:id/:dept'], function(req,res){
	var sql = 'SELECT * FROM 학과 WHERE 기관ID=?';
	conn.query(sql, function(err,results,fields){
		var dept = req.params.dept;
		if(dept){
			res.render('register_class2',{dept});
			console.log(dept);
		} else {
			res.render('DeptChoice',{results:results});
		}
	});
});


app.listen(3000,function(){
	console.log('Connected!');
});